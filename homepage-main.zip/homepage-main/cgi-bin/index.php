#!/usr/local/bin/php
<?php echo 'Sample CGI PHP Script';?>
