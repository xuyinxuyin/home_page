pwd
find ./images/ -type d -exec chmod a+rx {} +
find ./images/ -type f -exec chmod a+r {} +
find ./data/ -type d -exec chmod a+rx {} +
find ./data/ -type f -exec chmod a+r {} +
chmod a+rx ./projects/
chmod a+rx ./projects/cadex